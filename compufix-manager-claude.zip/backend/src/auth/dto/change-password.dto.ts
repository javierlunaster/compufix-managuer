import { IsNotEmpty, IsString, MinLength } from "class-validator";

export class ChangePasswordDto {
  @IsString()
  @IsNotEmpty({ message: "La contraseña actual es obligatoria" })
  currentPassword: string;

  @IsString()
  @MinLength(8, { message: "La nueva contraseña debe tener al menos 8 caracteres" })
  newPassword: string;
}
