@echo off
REM ============================================================
REM Lanzador de COMPufix Manager (modo desarrollo local)
REM Doble clic para levantar todo: base de datos + backend + frontend
REM ============================================================
setlocal

set "PROJECT_DIR=%~dp0"
cd /d "%PROJECT_DIR%"

echo === COMPufix Manager (modo desarrollo) ===
echo.

echo Verificando que Docker Desktop este corriendo...
docker info >nul 2>&1
if errorlevel 1 (
    echo.
    echo Docker Desktop no parece estar corriendo.
    echo Abrelo desde el menu de inicio, espera a que la ballena de la
    echo barra de tareas deje de moverse, y vuelve a hacer doble clic aqui.
    echo.
    pause
    exit /b 1
)

echo Iniciando la base de datos (Postgres)...
docker compose up -d

echo.
echo Abriendo el backend en una ventana nueva...
start "COMPufix - Backend" cmd /k "cd /d "%PROJECT_DIR%backend" && npm run start:dev"

echo Abriendo el frontend en una ventana nueva...
start "COMPufix - Frontend" cmd /k "cd /d "%PROJECT_DIR%frontend" && npm run dev"

echo.
echo Esperando a que el sistema termine de arrancar (unos segundos)...
timeout /t 12 /nobreak >nul

echo Abriendo el navegador...
start http://localhost:5173

echo.
echo ================================================================
echo  Listo. El backend y el frontend quedaron corriendo cada uno en
echo  su propia ventana - no las cierres mientras trabajas.
echo.
echo  Esta ventana se puede cerrar sin problema.
echo ================================================================
echo.
pause
